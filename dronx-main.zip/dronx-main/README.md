## How to use

Install it and run:

```sh
npm install
npm start
```
