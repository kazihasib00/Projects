__author__ = 'Kazi Hasib'


def admin_check(user):
    return user.is_superuser